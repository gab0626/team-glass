#include "player.h"

void nanntyara::setup()
{

}

void nanntyara::draw()
{

}