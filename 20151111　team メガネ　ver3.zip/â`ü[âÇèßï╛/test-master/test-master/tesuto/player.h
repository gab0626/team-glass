#pragma once
#include "lib\framework.hpp"

class nanntyara
{
private:

public:
	int a = 0;
	void draw();
	void setup();
};