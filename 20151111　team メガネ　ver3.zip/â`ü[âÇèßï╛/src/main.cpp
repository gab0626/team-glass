﻿//ここには自分が作ったヘッター（ファイル分け）などを
//インクルード（ここで処理してきたものを使えるようにする...みたいな？）
//させて使用します。
#include "lib/framework.hpp"
#include "singleton.h"
#include "Menu.h"
#include "Result.h"
#include "Title.h"
#include "Game.h"

//switch文で後々管理予定のシーン切り分け
enum GameChange
{
	TITLE,
	MENU,
	GAME,
	RESULT
};

//メインの中身
int main() {

	//インストラクター？をここで
	//グローバル変数やヘッターで決めた
	//セットアップをここに置く
	env;
	Title title;
	Game game;
	game.Setup();
		
  while (env.isOpen()) {
	  
	title.Setup();
	
	//whileのenv.begin()の中には物の描画や繰り返し処理してほしいもののみを入れる。
	//int mainの○○.Setup()と同様に
	//ここには○○.Draw()を置いていく。
    env.begin();


	title.Draw();
	
    
    env.end();
  }
}
